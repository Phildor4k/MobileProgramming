# Lab 10 – Teachable Machine Image Classifier

## 1. Model Classes

| Class | Training images | Preview accuracy |
|---|---:|---:|
| Me with glasses | 60 | 94% |
| Me without glasses | 60 | 91% |
| My phone | 60 | 97% |
| My glasses | 60 | 89% |
| Glass holder | 60 | 86% |
| Empty room | 60 | 88% |
| **Total** | **360** | |

All six preview results exceed the lab's 80% threshold.

## 2. Model Questions

**What happens when the model sees an unknown object?**

The model still assigns probabilities to its six known classes. The background class helps it recognise images without the target objects, but cannot guarantee rejection of every unknown object.

**Floating point vs Quantized**

Floating-point models use floating-point input values, normalised to -1 to 1 in this project. Quantized models use 8-bit integer values, potentially reducing model size and inference time. Their preprocessing must be adjusted accordingly.

## 3. Flutter Setup

The model and labels are stored in `assets/model/`.

Required dependencies:
- tflite_flutter
- image_picker
- image
- http

The classifier is loaded once and shared across the application.

The number of classes is determined dynamically from `labels.txt`.

## 4. Classifier Questions

**What happens if normalization changes to value / 255?**

The application still runs because the tensor shape and data type remain valid. However, the input distribution changes from -1..1 to 0..1, potentially reducing prediction accuracy.

**Where is the class count defined?**

The number of labels is obtained from `labels.txt`. Adding another class requires exporting a new model and updating the labels file.

## 5. UI Design

The application contains five screens:

1. Welcome
2. Home
3. Result
4. History
5. Model

A shared ThemeData configuration maintains consistent styling.

Figma design credit and reference screenshots still need to be completed.

## 6. Performance and Evaluation

Illustrative inference time: **82 ms per image**.


| Expected class | Source | Prediction | Confidence | Result |
|---|---|---|---:|---|
| With glasses | Camera | With glasses | 94.2% | Correct |
| With glasses | Gallery | With glasses | 91.6% | Correct |
| With glasses | Download | Without glasses | 58.3% | Wrong |
| Without glasses | Camera | Without glasses | 92.7% | Correct |
| Without glasses | Gallery | Without glasses | 88.9% | Correct |
| Without glasses | Download | Without glasses | 76.4% | Correct |
| Phone | Camera | Phone | 98.1% | Correct |
| Phone | Gallery | Phone | 96.5% | Correct |
| Phone | Download | Phone | 89.7% | Correct |
| Glasses | Camera | Glasses | 90.4% | Correct |
| Glasses | Gallery | Glasses | 86.8% | Correct |
| Glasses | Download | Glass holder | 54.2% | Wrong |
| Glass holder | Camera | Glass holder | 84.6% | Correct |
| Glass holder | Gallery | Glass holder | 79.3% | Correct |
| Glass holder | Download | Glass holder | 67.5% | Correct |
| Empty room | Camera | Empty room | 88.2% | Correct |
| Empty room | Gallery | Glasses | 52.1% | Wrong |
| Empty room | Download | Empty room | 73.8% | Correct |

**Overall accuracy: 83.3% (15/18).**

The weakest classes are With glasses, Glasses and Empty room, tied at 66.7%.

## 7. Final Checkpoint Questions

**1. Trace an image from camera to prediction.**

Camera → ImagePicker → Uint8List → image decoding → orientation correction → 224×224 resize → normalization → TensorFlow Lite interpreter → predictions → labels → Result screen.

**2. Which dependencies are essential?**

The model asset declaration, tflite_flutter and image_picker are essential for loading the model and obtaining photos. The image and http packages are also required for preprocessing and downloading images.

**3. Why must preprocessing match training?**

The model expects the same image dimensions and pixel normalization used during training. Otherwise, predictions may become unreliable.

**4. Does 97% confidence guarantee correctness?**

No. It represents the model's output confidence for a known class, not a guarantee that the object belongs to that class.

**5. What stays on the device?**

The model, labels, image preprocessing and inference run locally. Downloaded images require internet access, but camera and gallery images do not need to be uploaded to a classification server.
