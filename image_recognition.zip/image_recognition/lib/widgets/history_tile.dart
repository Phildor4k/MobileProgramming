import 'package:flutter/material.dart';
import '../models/history_entry.dart';
import '../screens/result_screen.dart';

class HistoryTile extends StatelessWidget {
  const HistoryTile({super.key, required this.entry});
  final HistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        contentPadding: const EdgeInsets.all(8),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.memory(entry.bytes,
              width: 56, height: 56, fit: BoxFit.cover, cacheWidth: 112),
        ),
        title: Text(entry.top.label),
        subtitle: Text('${(entry.top.confidence * 100).toStringAsFixed(1)} %'),
        trailing: Icon(sourceIcon(entry.source)),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => ResultScreen(entry: entry)),
        ),
      ),
    );
  }
}
