import 'package:flutter/foundation.dart';
import '../services/classifier.dart';
import '../services/image_sources.dart';
import 'history_entry.dart';

class AppState {
  AppState(this.classifier);
  final Classifier classifier;
  final sources = ImageSources();
  final history = ValueNotifier<List<HistoryEntry>>([]);
}
