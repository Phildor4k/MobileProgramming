import 'dart:typed_data';
import '../services/classifier.dart';

enum Source { camera, gallery, download }

extension SourceInfo on Source {
  String get title => switch (this) {
        Source.camera => 'Camera',
        Source.gallery => 'Gallery',
        Source.download => 'Download',
      };
}

class HistoryEntry {
  const HistoryEntry(this.bytes, this.predictions, this.source, this.time);
  final Uint8List bytes;
  final List<Prediction> predictions;
  final Source source;
  final DateTime time;

  Prediction get top => predictions.first;
}
