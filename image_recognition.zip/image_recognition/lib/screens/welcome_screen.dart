import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/classifier.dart';
import 'shell_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key, required this.loading});
  final Future<Classifier> loading;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: FutureBuilder<Classifier>(
          future: loading,
          builder: (context, snap) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Spacer(),
                  Icon(Icons.center_focus_strong,
                      size: 64, color: theme.colorScheme.primary),
                  const SizedBox(height: 16),
                  Text('Teach It, Ship It', style: theme.textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  Text(
                    'Point your phone at things around you and the app tells you what it sees, fully offline.',
                    style: theme.textTheme.bodyLarge,
                  ),
                  const SizedBox(height: 24),
                  if (snap.hasError)
                    Text(
                      'The model could not be loaded.\nExpected $modelPath and $labelsPath.\n\n${snap.error}',
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(color: theme.colorScheme.error),
                    )
                  else if (!snap.hasData)
                    const Row(children: [
                      SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 12),
                      Text('Loading model...'),
                    ])
                  else
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final label in snap.data!.labels)
                          Chip(label: Text(label)),
                      ],
                    ),
                  const Spacer(),
                  FilledButton(
                    onPressed: snap.hasData
                        ? () => Navigator.of(context).pushReplacement(
                              MaterialPageRoute(
                                builder: (_) =>
                                    ShellScreen(app: AppState(snap.data!)),
                              ),
                            )
                        : null,
                    child: const Text('Get started'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
