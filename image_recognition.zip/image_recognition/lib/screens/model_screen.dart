import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/classifier.dart';
import '../theme/app_theme.dart';

class ModelScreen extends StatelessWidget {
  const ModelScreen({super.key, required this.app});
  final AppState app;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final labels = app.classifier.labels;
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text('Model', style: theme.textTheme.headlineMedium),
        const SizedBox(height: 16),
        Card(
          child: Column(
            children: [
              ListTile(
                  title: const Text('Model file'),
                  trailing: Text(modelPath.split('/').last)),
              ListTile(
                  title: const Text('Classes'),
                  trailing: Text('${labels.length}')),
              const ListTile(
                  title: Text('Input size'),
                  trailing: Text('${Classifier.inputSize} x ${Classifier.inputSize}')),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Text('Labels', style: theme.textTheme.titleMedium),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [for (final l in labels) Chip(label: Text(l))],
        ),
        const SizedBox(height: 24),
        Text(designCredit, style: theme.textTheme.bodySmall),
      ],
    );
  }
}
