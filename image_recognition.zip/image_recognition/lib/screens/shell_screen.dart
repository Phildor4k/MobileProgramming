import 'package:flutter/material.dart';
import '../models/app_state.dart';
import 'history_screen.dart';
import 'home_screen.dart';
import 'model_screen.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key, required this.app});
  final AppState app;

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: _index,
          children: [
            HomeScreen(app: widget.app),
            HistoryScreen(app: widget.app),
            ModelScreen(app: widget.app),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(
              icon: Icon(Icons.memory_outlined), label: 'Model'),
        ],
      ),
    );
  }
}
