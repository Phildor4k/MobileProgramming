import 'package:flutter/material.dart';
import '../models/history_entry.dart';
import '../services/classifier.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.entry});
  final HistoryEntry entry;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final maxHeight = MediaQuery.of(context).size.height * 0.5;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Result'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Chip(
              avatar: Icon(sourceIcon(entry.source), size: 18),
              label: Text(entry.source.title),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxHeight: maxHeight),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.memory(entry.bytes, fit: BoxFit.contain),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              for (var i = 0; i < entry.predictions.length; i++)
                _Row(prediction: entry.predictions[i], top: i == 0, theme: theme),
            ],
          ),
        ),
      ),
    );
  }
}

IconData sourceIcon(Source s) => switch (s) {
      Source.camera => Icons.photo_camera,
      Source.gallery => Icons.photo_library,
      Source.download => Icons.cloud_download,
    };

class _Row extends StatelessWidget {
  const _Row({required this.prediction, required this.top, required this.theme});
  final Prediction prediction;
  final bool top;
  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    final style = top
        ? theme.textTheme.titleMedium
        : theme.textTheme.bodyMedium;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
              width: 110,
              child: Text(prediction.label,
                  style: style, overflow: TextOverflow.ellipsis)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: prediction.confidence.clamp(0.0, 1.0),
                minHeight: top ? 10 : 6,
                color: top ? theme.colorScheme.primary : theme.colorScheme.outline,
                backgroundColor: theme.colorScheme.surfaceContainerHighest,
              ),
            ),
          ),
          SizedBox(
            width: 64,
            child: Text(
              '${(prediction.confidence * 100).toStringAsFixed(1)} %',
              textAlign: TextAlign.right,
              style: style,
            ),
          ),
        ],
      ),
    );
  }
}
