import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../models/history_entry.dart';
import '../widgets/history_tile.dart';
import 'result_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.app});
  final AppState app;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _busy = false;

  void _message(String text) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _run(Source source, Future<Uint8List?> Function() getBytes) async {
    setState(() => _busy = true);
    try {
      final bytes = await getBytes();
      if (bytes == null) return;
      await Future.delayed(const Duration(milliseconds: 50));
      final predictions = widget.app.classifier.classify(bytes);
      final entry = HistoryEntry(bytes, predictions, source, DateTime.now());
      widget.app.history.value = [entry, ...widget.app.history.value];
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ResultScreen(entry: entry)),
      );
    } on FormatException catch (e) {
      if (mounted) _message(e.message);
    } catch (e) {
      if (mounted) _message('Something went wrong: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _askUrl() async {
    final controller = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Image address'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'https://...'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size(96, 44)),
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Download'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (url == null || url.trim().isEmpty) return;
    await _run(Source.download, () => widget.app.sources.fromUrl(url));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text('What should I look at?', style: theme.textTheme.headlineMedium),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: _busy
              ? null
              : () => _run(Source.camera, widget.app.sources.fromCamera),
          icon: const Icon(Icons.photo_camera),
          label: const Text('Take a photo'),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: _busy
              ? null
              : () => _run(Source.gallery, widget.app.sources.fromGallery),
          icon: const Icon(Icons.photo_library),
          label: const Text('Choose from gallery'),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: _busy ? null : _askUrl,
          icon: const Icon(Icons.cloud_download),
          label: const Text('Download an image'),
        ),
        const SizedBox(height: 24),
        if (_busy)
          const Center(child: CircularProgressIndicator())
        else
          ValueListenableBuilder<List<HistoryEntry>>(
            valueListenable: widget.app.history,
            builder: (context, list, _) {
              if (list.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Latest result', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 8),
                  HistoryTile(entry: list.first),
                ],
              );
            },
          ),
      ],
    );
  }
}
