import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../models/history_entry.dart';
import '../widgets/history_tile.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key, required this.app});
  final AppState app;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ValueListenableBuilder<List<HistoryEntry>>(
      valueListenable: app.history,
      builder: (context, list, _) {
        if (list.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.history,
                      size: 64, color: theme.colorScheme.outline),
                  const SizedBox(height: 12),
                  Text('Nothing here yet', style: theme.textTheme.titleLarge),
                  const SizedBox(height: 4),
                  Text('Classified pictures will show up here.',
                      style: theme.textTheme.bodyMedium,
                      textAlign: TextAlign.center),
                ],
              ),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(24),
          itemCount: list.length,
          separatorBuilder: (_, _) => const SizedBox(height: 12),
          itemBuilder: (_, i) => HistoryTile(entry: list[i]),
        );
      },
    );
  }
}
