import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

class ImageSources {
  final _picker = ImagePicker();

  Future<Uint8List?> fromCamera() => _pick(ImageSource.camera);

  Future<Uint8List?> fromGallery() => _pick(ImageSource.gallery);

  Future<Uint8List?> _pick(ImageSource source) async {
    final file = await _picker.pickImage(source: source, maxWidth: 1024);
    return file == null ? null : await file.readAsBytes();
  }

  Future<Uint8List> fromUrl(String url) async {
    final uri = Uri.tryParse(url.trim());
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      throw const FormatException('That is not a valid web address.');
    }
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) {
        throw FormatException(
            'The server answered with status ${response.statusCode}.');
      }
      final type = response.headers['content-type'] ?? '';
      if (!type.startsWith('image/')) {
        throw const FormatException('That address is not a picture.');
      }
      return response.bodyBytes;
    } on TimeoutException {
      throw const FormatException('The download took too long.');
    } on SocketException {
      throw const FormatException('No network connection.');
    } on http.ClientException {
      throw const FormatException('The download failed. Check the address and your connection.');
    }
  }
}
