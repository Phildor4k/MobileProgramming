import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import 'labels.dart';

const modelPath = 'assets/model/model_unquant.tflite';
const labelsPath = 'assets/model/labels.txt';

class Prediction {
  const Prediction(this.label, this.confidence);
  final String label;
  final double confidence;
}

class Classifier {
  Classifier._(this._interpreter, this.labels);

  final Interpreter _interpreter;
  final List<String> labels;

  static const inputSize = 224;

  static Future<Classifier> load() async {
    final interpreter = await Interpreter.fromAsset(modelPath);
    final labels = parseLabels(await rootBundle.loadString(labelsPath));
    return Classifier._(interpreter, labels);
  }

  List<Prediction> classify(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) throw const FormatException('Not a readable image');
    final square = img.copyResizeCropSquare(
      img.bakeOrientation(decoded),
      size: inputSize,
    );
    final input = [
      List.generate(
        inputSize,
        (y) => List.generate(inputSize, (x) {
          final p = square.getPixel(x, y);
          return [p.r / 127.5 - 1, p.g / 127.5 - 1, p.b / 127.5 - 1];
        }),
      ),
    ];
    final output = [List<double>.filled(labels.length, 0)];
    _interpreter.run(input, output);
    return [
      for (var i = 0; i < labels.length; i++)
        Prediction(labels[i], output.first[i]),
    ]..sort((a, b) => b.confidence.compareTo(a.confidence));
  }

  void close() => _interpreter.close();
}
