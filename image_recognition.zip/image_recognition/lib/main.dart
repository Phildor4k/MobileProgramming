import 'package:flutter/material.dart';
import 'screens/welcome_screen.dart';
import 'services/classifier.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Classifier? _classifier;
  late final Future<Classifier> _loading = Classifier.load().then((c) {
    _classifier = c;
    return c;
  });

  @override
  void dispose() {
    _classifier?.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Teach It, Ship It',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: WelcomeScreen(loading: _loading),
    );
  }
}
